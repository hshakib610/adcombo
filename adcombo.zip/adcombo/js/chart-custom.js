const ctx = document.getElementById('dash-chart').getContext('2d');

const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['oct:29', 'oct:28', 'oct:27', 'oct:26', 'oct:25', 'oct:24'],
        datasets: [{
            label: 'click',
            data:[],
            backgroundColor: [
               
            ],
            borderColor: [
                
            ],
            borderWidth: 1
        },{
            label: 'click',
            data:[],
            backgroundColor: [
                
            ],
            borderColor: [
                
            ]
        }
    ]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        },
        title: {
            display: true,
            text: 'Population growth (millions)'
          }
    }
});