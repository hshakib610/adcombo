try {
    var noscript = document.createElement('noscript');
    var pix = document.createElement('div');
    var pixImg = document.createElement('img');
    pixImg.setAttribute("src", "https://mc.yandex.ru/watch/69322111");
    pixImg.setAttribute("style", "position:absolute; left:-9999px;")
    pixImg.setAttribute("height", "1");
    pixImg.setAttribute("width", "1");
    pix.append(pixImg);
    noscript.append(pix)
    document.body.appendChild(noscript);
} catch (e) {

}

(function(d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter69322111 = new Ya.Metrika({
                id: 69322111,
                clickmap: true,
                trackLinks: true,
                accurateTrackBounce: true,
                webvisor: true
            });
        } catch (e) {}
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function() {
            n.parentNode.insertBefore(s, n);
        };
    s.type = "text/javascript";
    s.async = true;
    s.src = "https://mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else {
        f();
    }
})(document, window, "yandex_metrika_callbacks");