if (window.location.href.indexOf('login') < 0) {
    try {
        var img = document.createElement('img');
        img.onload = function() {
            window.sawpp = true;
        };
        img.onerror = function() {
            window.sawpp = false;
        };
        img.src = '//user-actrk.com/trk/sawpp.jpg';
        document.head.appendChild(img);
    } catch (e) {

    }
}