! function() {
    var t = document.createElement("script");
    t.type = "text/javascript", t.async = !0, t.src = "https://vk.com/js/api/openapi.js?160", t.onload = function() {
        VK.Retargeting.Init("VK-RTRG-332695-9fhUq"), VK.Retargeting.Hit()
    }, document.head.appendChild(t)
}();

try {
    var pix = document.createElement('noscript');
    var pixImg = document.createElement('img');
    pixImg.setAttribute("src", "https://vk.com/rtrg?p=VK-RTRG-332695-9fhUq");
    pixImg.setAttribute("style", "display:none;position:fixed; left:-999px;")
    pixImg.setAttribute("height", "1");
    pixImg.setAttribute("width", "1");
    pix.append(pixImg);
    document.head.appendChild(pix);
} catch (e) {
    console.log('browser not support noscript tag')
}